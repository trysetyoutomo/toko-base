define(function (require) {

    require('./heatmap/HeatmapSeries');
    require('./heatmap/HeatmapView');
});